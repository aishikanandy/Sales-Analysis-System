﻿---Project Scenario: Sales Analysis System Scenario:

----The management team at AdventureWorks wants a Sales Analysis System to analyze sales trends and manage product prices.

----They have outlined the following requirements:

-----1. Create a view to display all sales orders along with customer names, product names, and order totals.
-----2. Create a stored procedure to update product prices, ensuring that the new price is not lower than 50% of the product's current price.
-----3. Write a query to retrieve data from the view for analysis.
-----4. Execute the procedure to update the price of a specific product.

CREATE DATABASE SalesLT;--Create Database

GO

USE SalesLT;

GO

--Create 'Customers' table

CREATE TABLE Customers
(
    CustomerID INT PRIMARY KEY IDENTITY(1,1),
    FullName NVARCHAR(100) NOT NULL
);

GO

--Create 'Product' table

CREATE TABLE Products
(
    ProductID INT PRIMARY KEY IDENTITY(1,1),
    ProductName NVARCHAR(150) NOT NULL,
    Price DECIMAL(10,2) NOT NULL
);

GO

--Create 'SalesOrderHeader' table

CREATE TABLE SalesOrderHeader
(
    OrderID INT PRIMARY KEY IDENTITY(1,1),
    CustomerID INT NOT NULL,
    OrderDate DATE NOT NULL DEFAULT GETDATE(),
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
);

GO
--Create 'SalesOrderDetails' table

CREATE TABLE SalesOrderDetails
(
    OrderDetailID INT PRIMARY KEY IDENTITY(1,1),
    OrderID INT NOT NULL,
    ProductID INT NOT NULL,
    Quantity INT NOT NULL,
    FOREIGN KEY (OrderID) REFERENCES SalesOrderHeader(OrderID),
    FOREIGN KEY (ProductID) REFERENCES Products(ProductID)
);

GO

---Insert sample data to the tables---

INSERT INTO Customers (FullName)

VALUES

('John Doe'),
('Sarah Williams'),
('Michael Smith'),
('Emma Johnson'),
('David Miller');

GO

INSERT INTO Products (ProductName, Price)

VALUES

('Mountain Bike', 1200.00),
('Road Helmet', 85.00),
('Cycling Gloves', 30.00),
('LED Bike Light', 45.00),
('Water Bottle', 15.00);

GO

INSERT INTO SalesOrderHeader (CustomerID, OrderDate)

VALUES

(1, '2024-01-10'),
(2, '2024-01-12'),
(3, '2024-01-13'),
(1, '2024-01-15'),
(4, '2024-01-16');

GO

INSERT INTO SalesOrderDetails (OrderID, ProductID, Quantity)

VALUES

(1, 1, 1),---John bought a Mountain Bike
(1, 3, 2),---John bought 2 Cycling Gloves
(2, 2, 1),---Sara bought a Road Helmet
(3, 4, 3),---Michel bought 3 LED Bike Lights
(4, 5, 4), ---John bought 4 Water Bottles
(5, 1, 1);---Emma bought a Mountain Bike

GO

---Create the View
----View Requirement: The view should display the following details:
-----● Sales Order ID
-----● Customer Name (FirstName + LastName)
-----● Product Name
-----● Quantity Ordered
-----● Total Price for the Product (OrderQty * UnitPrice)

CREATE VIEW vw_SalesOrderDetails

AS

SELECT

SOH.OrderID,

C.FullName,

P.ProductName,

SOD.Quantity AS TotalUnitsSold,

(SOD.Quantity*P.Price) AS TotalPrice

FROM Customers AS C

JOIN SalesOrderHeader AS SOH ON C.CustomerID=SOH.CustomerID

JOIN SalesOrderDetails AS SOD ON SOD.OrderID=SOH.OrderID

JOIN Products AS P ON P.ProductID=SOD.ProductID;

GO

--Query the View--

SELECT * FROM vw_SalesOrderDetails

WHERE FullName = 'John Doe'

ORDER BY TotalPrice DESC;

--Create the stored procedure--

---Create a stored procedure to update a product's price (ListPrice) in the SalesLT.Product table.
---Ensure the new price is not less than 50% of the current price.
---If the new price is too low, display an error message.

CREATE PROCEDURE UpdateProductPrice (@ProductID INT, @NewPrice DECIMAL(10, 2))

AS

BEGIN

    DECLARE @CurrentPrice DECIMAL(10,2); ---Declaring a variable to hold the current price

    SELECT @CurrentPrice=P.Price ---Fetch the current price

    FROM Products AS P

    WHERE ProductID=@ProductID

-- Check 50% rule

        IF @NewPrice < (@CurrentPrice * 0.5)

        BEGIN

         PRINT 'Error: New price cannot be less than 50% of current price.';

        RETURN;

        END

 -- Update price

    UPDATE Products

    SET Price = @NewPrice

    WHERE ProductID = @ProductID;

    PRINT 'Price updated successfully.';

END;

GO

---Execute the Stored Procedure

EXEC UpdateProductPrice

@ProductID=3,
@NewPrice=150.00

---Conclusion:
----The Sales Analysis System successfully integrates customer, product, and order data to simplify sales reporting and analysis.
----It also ensures secure price updates through a controlled stored procedure that maintains data integrity.